<!DOCTYPE html>
<html>
	<head>
		<meta content="text/html; charset=utf-8" />
		<title>Login Systeem</title>
		
                <style>
                    *
{
	margin:0;
	padding:0;
}
#login-form
{
	margin-top:70px;
}
table
{
	border:solid #dcdcdc 1px;
	padding:25px;
	box-shadow: 0px 0px 1px rgba(0,0,0,0.2);
}
table tr,td
{
	padding:15px;
	//border:solid #e1e1e1 1px;
}
table tr td input
{
	width:97%;
	height:45px;
	border:solid #e1e1e1 1px;
	border-radius:3px;
	padding-left:10px;
	font-family:Verdana, Geneva, sans-serif;
	font-size:16px;
	background:#f9f9f9;
	transition-duration:0.5s;
	box-shadow: inset 0px 0px 1px rgba(0,0,0,0.4);
}

table tr td button
{
	width:100%;
	height:45px;
	border:0px;
	background:rgba(12,45,78,11);
	background:-moz-linear-gradient(top, #595959 , #515151);
	border-radius:3px;
	box-shadow: 1px 1px 1px rgba(1,0,0,0.2);
	color:#f9f9f9;
	font-family:Verdana, Geneva, sans-serif;
	font-size:18px;
	font-weight:bolder;
	text-transform:uppercase;
}
table tr td button:active
{
	position:relative;
	top:1px;
}
table tr td a
{
	text-decoration:none;
	color:#00a2d1;
	font-family:Verdana, Geneva, sans-serif;
	font-size:18px;
}
                </style>
	</head>
	<body>
		<center>
			<div id="login-form">
				<form method="post">
					<table align="center" width="30%" border="0">
						<tr>
							<td><input type="text" name="uname" placeholder="Naam" required /></td>
						</tr>
						<tr>
							<td><input type="email" name="email" placeholder="Email" required /></td>
						</tr>
						<tr>
							<td><input type="password" name="pass" placeholder="Wachtwoord" required /></td>
						</tr>
						<tr>
							<td><button type="submit" name="btn-signup">Registreer</button></td>
						</tr>
						<tr>
							<td><a href="login">Home Pagina</a></td>
						</tr>
					</table>
				</form>
			</div>
		</center>
	</body>
</html>

